from django.apps import AppConfig


class FindFoodConfig(AppConfig):
    name = 'find_food'
